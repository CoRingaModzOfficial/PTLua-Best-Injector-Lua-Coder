package com.CMStudio;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.content.Intent;
import android.content.ClipData;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.view.View;
import android.widget.AdapterView;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {

    public final int REQ_CD_LUA = 101;

    private String path = "";

    private ArrayList<String> spinner = new ArrayList<>();
    private ArrayList<String> list = new ArrayList<>();
    private ArrayList<String> str = new ArrayList<>();
    private ArrayList<String> strv = new ArrayList<>();

    private ScrollView vscroll1;
    private LinearLayout linear1;
    private LinearLayout linear4;
    private LinearLayout linear6;
    private LinearLayout linear8;
    private LinearLayout linear9;
    private EditText fonter;
    private TextView textview5;
    private TextView textview7;
    private LinearLayout linear5;
    private LinearLayout linear2;
    private LinearLayout linear7;
    private LinearLayout linear3;
    private ImageView imageview1;
    private TextView textview1;
    private ScrollView vscroll2;
    private EditText edittext1;
    private TextView textview2;
    private Spinner spinner1;
    private Button button1;
    private Button button2;
    private TextView textview3;
    private EditText edittext2;
    private EditText edittext3;
    private Button button3;
    private TextView textview4;
    private EditText edittext4;
    private Button button4;
    private TextView textview6;
    private EditText edittext5;
    private Button button5;
    
    private LinearLayout linear10;

    private Intent lua = new Intent(Intent.ACTION_GET_CONTENT);
    private AlertDialog.Builder popupcredits;
    private Intent youtube = new Intent();
    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(_savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            }
            else {
                initializeLogic();
            }
        }
        else {
            initializeLogic();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            initializeLogic();
        }
    }

    private void initialize(Bundle _savedInstanceState) {

        vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
        linear1 = (LinearLayout) findViewById(R.id.linear1);
        linear4 = (LinearLayout) findViewById(R.id.linear4);
        linear6 = (LinearLayout) findViewById(R.id.linear6);
        linear8 = (LinearLayout) findViewById(R.id.linear8);
        linear9 = (LinearLayout) findViewById(R.id.linear9);
        fonter = (EditText) findViewById(R.id.fonter);
        textview5 = (TextView) findViewById(R.id.textview5);
        textview7 = (TextView) findViewById(R.id.textview7);
        linear5 = (LinearLayout) findViewById(R.id.linear5);
        linear2 = (LinearLayout) findViewById(R.id.linear2);
        linear7 = (LinearLayout) findViewById(R.id.linear7);
        linear3 = (LinearLayout) findViewById(R.id.linear3);
        imageview1 = (ImageView) findViewById(R.id.imageview1);
        textview1 = (TextView) findViewById(R.id.textview1);
        vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
        edittext1 = (EditText) findViewById(R.id.edittext1);
        textview2 = (TextView) findViewById(R.id.textview2);
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        textview3 = (TextView) findViewById(R.id.textview3);
        edittext2 = (EditText) findViewById(R.id.edittext2);
        edittext3 = (EditText) findViewById(R.id.edittext3);
        button3 = (Button) findViewById(R.id.button3);
        textview4 = (TextView) findViewById(R.id.textview4);
        edittext4 = (EditText) findViewById(R.id.edittext4);
        button4 = (Button) findViewById(R.id.button4);
        textview6 = (TextView) findViewById(R.id.textview6);
        edittext5 = (EditText) findViewById(R.id.edittext5);
        button5 = (Button) findViewById(R.id.button5);
        
        linear10 = (LinearLayout) findViewById(R.id.linear10);
        lua.setType("*/*");
        lua.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        popupcredits = new AlertDialog.Builder(this);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
                    final int _position = _param3;
                    if (_position == 0) {
                        Toast.makeText(getApplicationContext(), "❌De Voltar❌", Toast.LENGTH_SHORT).show();
                    }
                    if (_position == 1) {
                        linear6.setVisibility(View.VISIBLE);
                        fonter.setText("local username = \"NOME1\"\nlocal password = \"SENHA1\"\n\nlocal prompt = gg.prompt({\"👤Username\",\"🔑Password\"},nil,{\"text\",\"text\"}) or {\"\",\"\"}\n\nif prompt[1] ~= username then\nwhile(true) do\ngg.alert(\"❌Username Wrong\")\nos.exit()\nend\nend\nif prompt[2] ~= password then\nwhile(true) do\ngg.alert(\"❌Password Wrong\")\nos.exit()\nend\nend\n---CoRingaModz\n---DarkingCheater\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 2) {
                        linear8.setVisibility(View.VISIBLE);
                        fonter.setText("local script_name = \"LUANN.lua\"\nif script_name ~= gg.getFile():match(\".+/(.-)$\") then\nwhile(true) do\nlocal choice = gg.alert(\"❌ Wrong name, please rename script for: \"..script_name,\"❌Exit\",\"📋Copy Name\")\nif choice == 2 then\ngg.copyText(script_name,false)\nend\nif choice == 1 then\nos.exit()\nend\nend\nend\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 3) {
                        linear9.setVisibility(View.VISIBLE);
                        fonter.setText("gg.alert(\"ALERTROLA\")\nfunction LetterToastReverse(word) \nlocal TempWord = \"\" \nfor x = 0,word:len() do \nTempWord = TempWord..word:sub(word:len() - x,word:len() - x)  \ngg.toast((\" \"):rep(word:len() -x)..TempWord:reverse()) \ngg.sleep(450) \nend \nend \n LetterToastReverse(\"ALERTROLA\")\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 4) {
                        fonter.setText("if gg.isPackageInstalled(\"com.gmg.id\") then\n  gg.toast(\"✔Descompilador Dectado🔍\")\n  print(\"⚠ No se permite usar con ese Game Guardian ⚠\")\n  os.exit()\nend\nif gg.isPackageInstalled(\"sstool.only.com.sstool\") then\n  gg.toast(\"✔sstool only Dectado🔍\")\n  print(\"⚠ desinstalar sstool only ⚠\")\n  os.exit()\nend\nif gg.isPackageInstalled(\"io.neoterm\") then\n  gg.toast(\"✔neoterm Dectado🔍\")\n  print(\"⚠ No se permite usar neoterm ⚠\")\n  os.exit()\nend\nif gg.isPackageInstalled(\"com.sstool.only.sstool\") then\n  gg.toast(\"✔sstool only Dectado🔍\")\n  print(\"⚠ desinstalar sstool only ⚠\")\n  os.exit()\nend\n\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 5) {
                        fonter.setText("local _  =  debug.getinfo(gg.searchNumber).source ~= \"=[Java]\" or  not not debug.getupvalue(gg.searchNumber,1,2) \nlocal _ = _  == false or (function() gg.alert(\"🔥DETECTED HOOK🔥\",\"\",\"\",\"\")\nos.exit()\n end)()\n\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 6) {
                        fonter.setText("\nProgressBar =\"║░░░░░░░░░░░░░░░║\";for x = 1,16,1 do gg.sleep(500) ProgressBar = ProgressBar:gsub(\"░\",\"▓\",1);gg.toast(ProgressBar) end\n\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 7) {
                        fonter.setText("load = function(str) local i = \"\";repeat i = i.. string.char(math.random(97,122)) until #i > 10;package.path = \"?\";local ii = (gg.EXT_STORAGE)..\"/\"..i;io.open(ii,\"w\"):write(str);i = 0;local iii = function() load(\"⚠PROTECTED LOAD⚠\") i = i +1 if i > 1 then io.open(ii,\"w\"):write(str) os.remove(ii) debug.sethook(iii,\"\") end end;debug.sethook(iii,\"cr\");local iiii = pcall(require,ii) return end\n\n---CoRingaModz-----> \n---Darking Cheater----->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 8) {
                        fonter.setText("local Text = \"😈YOU FLOOD TEXT😈\"\nlocal Rep = 20 --Time to repeat\nfor k,v in pairs(gg) do\nif type(v) == \"function\" and k ~= \"isPackageInstalled\" then\ndef = function(...)\n\ngg.isPackageInstalled(Text:rep(Rep))\nreturn v(table.unpack({...}))\nend\n\n_G[\"gg\"][k] = def\n\nend\nend\n\n---CoRingaModz-----> \n---DarkingCheater-----> \n".concat(fonter.getText().toString()));
                    }
                    if (_position == 9) {
                        fonter.setText("for x =0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local x = {} x[''] = x local t = (x)(x, x) t[1] = 1 end\n\n----CoRingaModz---->\n----DarkingCheater---->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 10) {
                        fonter.setText("local hook = gg.searchNumber\nlocal hook2  = gg.editAll\n\ngg.editAll = function(...) \nparm = {...}\nif not(parm[1]) then\nreturn\nend\nparm[1]  = tostring(parm[1])\nparm[1] = parm[1]:gsub(\"%d+\",function(x)\nlocal rand = {\"y\",\"z\",\"=\",\"l\",\"g\",\"t\"}\nreturn x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500)\nend)\nhook2(table.unpack(parm))\nend\n\ngg.searchNumber = function(...) \nparm = {...}\nif not(parm[1]) then\nreturn\nend\nparm[1]  = tostring(parm[1])\nparm[1] = parm[1]:gsub(\"%d+\",function(x)\nlocal rand = {\"y\",\"z\",\"=\",\"l\",\"g\",\"t\"}\nreturn x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500)\nend)\nhook(table.unpack(parm))\nend\n----CoRingaModz---->\n----DarkingCheater---->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 11) {
                        fonter.setText("while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end\n----CoRingaModz---->\n----DarkingCheater---->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 12) {
                        fonter.setText("function replaced(repl)\n   num = num + 1\n local tbl = hex2tbl(repl)\n if src ~= nil then\n        local source = hex2tbl(src)\n       for i, v in ipairs(tbl) do\n            if v ~= \"??\" and v ~= \"**\" and v == source[i] then tbl[i] = \"**\" end\n        end\n       src = nil\n end\n   local cnt = #tbl\n  local set = {}\n    local s = 0\n   for _, addr in ipairs(results) do\n     for i, v in ipairs(tbl) do\n            if v ~= \"??\" and v ~= \"**\" then\n               s = s + 1\n             set[s] = {\n                    [\"address\"] = addr + i, \n                    [\"value\"] = v..\"r\",\n                   [\"flags\"] = gg.TYPE_BYTE,\n               }\n         end\n       end     \n  end\n   if s ~= 0 then gg.setValues(set) end\n  ok = true\nend\nfunction Squid(A0_24)\n    return (A0_24:gsub(\"..\", function(A0_25)\n      return string.char((tonumber(A0_25, 16) + 256 - 34 + 255999744) % 256)\n    end))\n  end\n  if _G[\"debug\"][\"getinfo\"](gg.alert).source == \"=[Java]\" then\n  else\n    i = 1\n    gg.setVisible(false)\n    while true do\n      i = i + 1\n      file = io.open(\"/storage/emulated/0/\" .. i, \"w\")\n      file:write(\"-- CoRingaBR Ant Hook\")\n      file:close()\n      gg.setVisible(false)\n      gg.processKill()\n      gg.setVisible(true)\n    end\n    return\nend \n  save = {}\n  for _FORV_27_ = 1, 10000 do\n    table.insert(save, {\n      [\"address\"] = 0 + _FORV_27_,\n      [\"flags\"] = 12\n    })\n  end\n  time = _G[\"os\"][\"clock\"]()\n  for _FORV_27_ = 1, 5 do\n    _G[\"gg\"][\"addListItems\"](save)\n  end\n  if 2 <= _G[\"os\"][\"clock\"]() - time then\n    _G[\"gg\"][\"removeListItems\"](save)\n    i = 1\n      gg.setVisible(false)\n    while true do\n      i = i + 1\n      gg.alert(\"🚫Script Ant Hook🚫Ant Hook\",\"Falhor\")\n      print(\"🐮CoRinga BR Protect\")\n      file = io.open(\"/storage/emulated/0/\" .. i, \"w\")\n      file:write(\"-- CoRinga BR Anti Log\")\n      file:close()\n      gg.setVisible(false)\n      gg.processKill()\n      gg.setVisible(true)\n    end\n    return\n   end \n      _G[\"gg\"][\"removeListItems\"](save)\n----CoRingaModz---->\n----DarkingCheater---->\n".concat(fonter.getText().toString()));
                    }
                    if (_position == 13) {
                        if (fonter.getText().toString().contains(fonter.getText().toString())) {
                            fonter.setText(fonter.getText().toString().replace("nil,'", "\"\",\""));
                            fonter.setText(fonter.getText().toString().replace("'", "\""));
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Nenhum Texto para editar", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> _param1) {

                }
            });

        button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    startActivityForResult(lua, REQ_CD_LUA);
                }
            });

        button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    FileUtil.writeFile(edittext1.getText().toString(), fonter.getText().toString());
                    Toast.makeText(getApplicationContext(), "💯Injectado Com Sucess💯", Toast.LENGTH_SHORT).show();
                }
            });

        button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if (fonter.getText().toString().contains(fonter.getText().toString())) {
                        fonter.setText(fonter.getText().toString().replace("NOME1", edittext2.getText().toString()));
                        fonter.setText(fonter.getText().toString().replace("SENHA1", edittext3.getText().toString()));
                        Toast.makeText(getApplicationContext(), "💯 Selecionado💯", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Nenhum Texto para editar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if (fonter.getText().toString().contains(fonter.getText().toString())) {
                        fonter.setText(fonter.getText().toString().replace("LUANN", edittext4.getText().toString()));
                        Toast.makeText(getApplicationContext(), "💯 Selecionado💯", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Nenhum Texto para editar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        button5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View _view) {
                    if (fonter.getText().toString().contains(fonter.getText().toString())) {
                        fonter.setText(fonter.getText().toString().replace("ALERTROLA", edittext5.getText().toString()));
                        Toast.makeText(getApplicationContext(), "💯 Selecionado💯", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Nenhum Texto para editar", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            }
    private void initializeLogic() {
        linear6.setVisibility(View.GONE);
        linear8.setVisibility(View.GONE);
        linear9.setVisibility(View.GONE);
        spinner.add("🔻SPINNER🔻");
        spinner.add("PASSWORD");
        spinner.add("ANT RENOMEAR");
        spinner.add("ANIMATED ALERT");
        spinner.add("BLOCK DE PACKAGE");
        spinner.add("HOOK DETECTOR");
        spinner.add("PROGRESSBAR");
        spinner.add("LOAD PROTECTOR");
        spinner.add("LOG FLOOD");
        spinner.add("ANT SSTOOL");
        spinner.add("LOG CONFUSER");
        spinner.add("ANT UNLUAC");
        spinner.add("ANT HOOK");
        spinner.add("Modelo - RadionButton");
        spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, spinner));
        popupcredits.setTitle("Credits : App Injected");
        popupcredits.setMessage("Version app :v1.0\napp New\n\nInformation: \n-Base/RadionButton\n\nCredits : App / Code\n@CoRingaModz\n@DarkingCheater");
        popupcredits.setPositiveButton("CHANNEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface _dialog, int _which) {
                    youtube.setAction(Intent.ACTION_VIEW);
                    youtube.setData(Uri.parse("https://www.youtube.com/channel/UCFG2M77_Opro1wRlmhOQHAQ"));
                    startActivity(youtube);
                }
            });
        popupcredits.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface _dialog, int _which) {
                    Toast.makeText(getApplicationContext(), "Bem Vindo!!", Toast.LENGTH_SHORT).show();
                }
            });
        popupcredits.create().show();
    }

    @Override
    protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
        super.onActivityResult(_requestCode, _resultCode, _data);

        switch (_requestCode) {
            case REQ_CD_LUA:
                if (_resultCode == Activity.RESULT_OK) {
                    ArrayList<String> _filePath = new ArrayList<>();
                    if (_data != null) {
                        if (_data.getClipData() != null) {
                            for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
                                ClipData.Item _item = _data.getClipData().getItemAt(_index);
                                _filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
                            }
                        }
                        else {
                            _filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
                        }
                    }
                    path = _filePath.get((int)(0));
                    list.add(path);
                    edittext1.setText(list.get((int)(0)));
                    fonter.setText(FileUtil.readFile(_filePath.get((int)(0))));
                }
                else {

                }
                break;
            default:
                break;
        }
    }

    @Deprecated
    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View _v) {
        int _location[] = new int[2];
        _v.getLocationInWindow(_location);
        return _location[0];
    }

    @Deprecated
    public int getLocationY(View _v) {
        int _location[] = new int[2];
        _v.getLocationInWindow(_location);
        return _location[1];
    }

    @Deprecated
    public int getRandom(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
        ArrayList<Double> _result = new ArrayList<Double>();
        SparseBooleanArray _arr = _list.getCheckedItemPositions();
        for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
            if (_arr.valueAt(_iIdx))
                _result.add((double)_arr.keyAt(_iIdx));
        }
        return _result;
    }

    @Deprecated
    public float getDip(int _input){
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels(){
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels(){
        return getResources().getDisplayMetrics().heightPixels;
    }

}

